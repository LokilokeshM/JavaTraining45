package com.java.Day5;

import java.io.Serializable;
import java.util.Random;

public class EmployeeDetails implements Serializable {

	Random rand = new Random();

	public int employeeId = rand.nextInt(10000);
	public String employeeName;
	public String jobDesignation;
	public int Experience;
	

	public EmployeeDetails(int employeeId, String employeeName, String jobDesignation,
			int experience) {
			this.employeeId = employeeId;
			this.employeeName= employeeName;
			this.jobDesignation= jobDesignation;
			this.Experience= experience;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getJobDesignation() {
		return jobDesignation;
	}

	public void setJobDesignation(String jobDesignation) {
		this.jobDesignation = jobDesignation;
	}

	public int getExperience() {
		return Experience;
	}

	public void setExperience(int experience) {
		Experience = experience;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Experience;

		result = prime * result + employeeId;
		result = prime * result + ((employeeName == null) ? 0 : employeeName.hashCode());
		result = prime * result + ((jobDesignation == null) ? 0 : jobDesignation.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "Employee [rand=" + rand + ", employeeId=" + employeeId + ", employeeName=" + employeeName
				+ ", jobDesignation=" + jobDesignation + ", Experience=" + Experience + "]";
	}

}
