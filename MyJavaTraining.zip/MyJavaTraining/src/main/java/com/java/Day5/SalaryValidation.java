package com.java.Day5;

import java.util.Random;

public class SalaryValidation extends EmployeeDetails{

	public int salary;
	public SalaryValidation(int employeeId, String employeeName, String jobDesignation, int experience) {
		super(employeeId, employeeName, jobDesignation, experience);
		// TODO Auto-generated constructor stub
	}

	void SetSalaray()
	{
		int experience = getExperience();
		if(experience <= 0)
		{
			salary = 10000;
		}
		else if(experience >= 1)
		{
			salary = 20000;
		}
		else if(experience >= 2)
		{
			salary = 40000;
		}
		else
		{
			System.out.println("Your Salary is not fixed");
		}
	}
}
