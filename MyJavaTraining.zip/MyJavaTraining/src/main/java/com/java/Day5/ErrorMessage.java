package com.java.Day5;

abstract class ErrorMessage {
ErrorMessage(String e)
 {
	 System.out.println(e);
 }
}
