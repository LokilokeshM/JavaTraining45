package com.java.Day5;

import java.io.Serializable;

public class OrderDetails {

	public int orderId;
	public String orderName;
	public int orderAmount;
	public String orderLocation;

	public OrderDetails(int orderId, String orderName, int orderAmount, String orderLocation) {
		super();
		this.orderId = orderId;
		this.orderName = orderName;
		this.orderAmount = orderAmount;
		this.orderLocation = orderLocation;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public int getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(int orderAmount) {
		this.orderAmount = orderAmount;
	}

	public String getOrderLocation() {
		return orderLocation;
	}

	public void setOrderLocation(String orderLocation) {
		this.orderLocation = orderLocation;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + orderAmount;
		result = prime * result + orderId;
		result = prime * result + ((orderLocation == null) ? 0 : orderLocation.hashCode());
		result = prime * result + ((orderName == null) ? 0 : orderName.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ", orderName=" + orderName + ", orderAmount=" + orderAmount
				+ ", orderLocation=" + orderLocation + "]";
	}

}
