package com.java.Day5;

import java.util.*;
import java.io.*;
public class Employee {
	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		List<EmployeeDetails> employeeObj = new ArrayList<>();
		String name;
		String jobDesignation = null;
		int Experience;

		
		
		try 
	     {
	          FileWriter fw=new FileWriter("../Desktop/input.txt");
	          
	          System.out.println("Enter How many Employee Details are need to add");
				int n= sc.nextInt();
				for(int i=0;i<n;i++)
				{
					System.out.println("Enter the Name ");
					name=sc.next();
					System.out.println("Enter the job");
					jobDesignation = sc.next();
					System.out.println("Enter the Experience");
					Experience = sc.nextInt();
					employeeObj.add(new EmployeeDetails(getEmployeeId(), name, jobDesignation, Experience));
				}
				
				Iterator itr= employeeObj.iterator();
				while(itr.hasNext())
				{
					fw.write(itr.next().toString());
					
//					System.out.println("==>"+itr.next().toString());
//					new SalaryValidation(n, jobDesignation, jobDesignation, n).SetSalaray();
				}   
				
				fw.close();
				//Read the Input File
	          FileReader filereadObj=new FileReader("../Desktop/input.txt");    
	          int iterator;    
	          while((iterator=filereadObj.read())!=-1)    
	          System.out.print((char)iterator);    
	          filereadObj.close();    
	       }
	     catch(Exception e)
	     {
	    	 FileWriter fe = new FileWriter("../Desktop/Error.txt");
	      	fe.write(e.getMessage());
	      	fe.close();
	     }
	     System.out.println("File Created Sucessfully");
	}	
	
	




	private static int getEmployeeId() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		return rand.nextInt(10000);
	}

}
