package com.java.Day5;

import java.util.*;
import java.io.*;
public class Employee {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		List<EmployeeDetails> employeeObj = new ArrayList<>();
		String name;
		String jobDesignation = null;
		int Experience;
	 try {
		 System.out.println("Enter How many Employee Details are need to add");
			int n= sc.nextInt();
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter the Name ");
				name=sc.next();
				System.out.println("Enter the job");
				jobDesignation = sc.next();
				System.out.println("Enter the Experience");
				Experience = sc.nextInt();
				employeeObj.add(new EmployeeDetails(getEmployeeId(), name, jobDesignation, Experience));
			}
			
			Iterator itr= employeeObj.iterator();
			while(itr.hasNext())
			{
				System.out.println("==>"+itr.next().toString());
				new SalaryValidation(n, jobDesignation, jobDesignation, n).SetSalaray();
			}
	 }
	 catch(Exception e)
	 {
		 ErrorMessage(e.getMessage());
	 }
	}
	private static void ErrorMessage(String message) {
		System.out.println(message);
		
	}



	private static int getEmployeeId() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		return rand.nextInt(10000);
	}

}
