package com.java.Day5;

import java.io.File;

public class HashcodeForFile {

	public static void main(String[] args) {
		File f = null;
		int v;
		boolean bool = false;

		try {

			f = new File("C:\\test.txt");
			v = f.hashCode();
			bool = f.exists();
			if (bool) {
				System.out.print("The hash code for this abstract path name: " + v);
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
