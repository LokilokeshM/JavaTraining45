package com.java.Day5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.TreeMap;

public class ViewOrder {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Map orderObj = new TreeMap();
		String name;
		int amount;
		String location;
	 try {
		 System.out.println("Enter How many Employee Details are need to add");
			int n= sc.nextInt();
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter the Order Name ");
				name=sc.next();
				System.out.println("Enter the Locations");
				location = sc.next();
				System.out.println("Enter the Amount");
				 amount= sc.nextInt();
//				 OrderDetails obj1 = new OrderDetails(getOrderId(),name,amount,location);
//				 orderObj.put(getOrderId(),obj1);
			}
			
			//Collections.sort(orderObj);
//			Iterator itr= orderObj.iterator();
//			while(itr.hasNext())
//			{
//				System.out.println("==>"+itr.next().toString());
//			}
	 }
	 catch(Exception e)
	 {
		 ErrorMessage(e.getMessage());
	 }
	}
	private static void ErrorMessage(String message) {
		System.out.println(message);
		
	}



	private static int getOrderId() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		return rand.nextInt(10000);
	}
}

