package com.java.Day5;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.TreeMap;

public class ViewOrder {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		List<OrderDetails> orderobj = new ArrayList<OrderDetails>();
		String name;
		int amount;
		String location;
	 try {
		 FileWriter fw=new FileWriter("../Desktop/input.txt");
		 System.out.println("Enter How many Employee Details are need to add");
			int n= sc.nextInt();
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter the Order Name ");
				name=sc.next();
				System.out.println("Enter the Locations");
				location = sc.next();
				System.out.println("Enter the Amount");
				 amount= sc.nextInt();
				 orderobj.add(new OrderDetails(i, name, amount, location));
				 fw.write(orderobj.toString());
			}
			fw.close();
				FileReader filereadObj=new FileReader("../Desktop/input.txt");    
	          int iterator;    
	          while((iterator=filereadObj.read())!=-1)    
	          System.out.print((char)iterator);    
	          filereadObj.close(); 
			//Collections.sort(orderObj);
//			Iterator itr= orderObj.iterator();
//			while(itr.hasNext())
//			{
//				System.out.println("==>"+itr.next().toString());
//			}
	 }
	 catch(Exception e)
	 {
		 ErrorMessage(e.getMessage());
	 }
	}
	private static void ErrorMessage(String message) {
		System.out.println(message);
		
	}



	private static int getOrderId() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		return rand.nextInt(10000);
	}
}

