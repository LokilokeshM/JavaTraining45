package com.java.Day2.ShippingModel;

import java.util.Random;
import java.util.Scanner;


public class ShippinModel extends Product implements AmountCalculation{

	public static void main(String[] args) {
		Mobile obj = new Mobile();
		Product obj1;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Product Name:");
		String name = sc.nextLine();
		System.out.println("Enter the Product Quantity:");
		int quantity = sc.nextInt();
		System.out.println("Enter the Ram Size");
		int ram = sc.nextInt();
		int sd = 256;
		String os = "Android";
	
		obj.SetProductDetails(sd, os, sd);
		obj.ShowProductDetails();
		
		System.out.println(new ShippinModel().cal());

	}
	
	public int cal() {
		int quanity = getQuantity();
		return quantity*100;
		
		
	}
	

}
