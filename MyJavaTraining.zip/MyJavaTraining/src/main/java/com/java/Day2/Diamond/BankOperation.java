package com.java.Day2.Diamond;

public class BankOperation extends CustomerBankDetails implements BalanceInquiry{
	String CustName,Email,BankName;
	Long AccountNo,PhoneNo;
	double Amount=0;
	public BankOperation(String CustName,String Email,String BankName,Long AccountNo,Long PhoneNo,double Amount) {
	super(CustName,Email,BankName,AccountNo,PhoneNo);
	this.Amount=Amount;
    }
	public void getDetails() {
		System.out.println("Bank Name : "+super.BankName);
		System.out.println("Customer Name : "+super.CustName);
		System.out.println("Email-Id : "+super.Email);
		System.out.println("Account Number : "+super.AccountNo);
		System.out.println("Phone Number :  "+super.PhoneNo);
	}
	@Override
	public void checkBalance(double Amt) 
	{
		Amount=Amt;
		if(Amount<=0)
		{
			System.out.println("Minimum Balance Required Rs.500");
		}
		
		System.out.println("Available Balance : "+Amount);
	}
		
}

