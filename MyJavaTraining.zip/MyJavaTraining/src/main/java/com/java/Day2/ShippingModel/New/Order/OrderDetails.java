package com.java.Day2.ShippingModel.New.Order;

import com.java.Day2.ShippingModel.New.Products.ProductDetails;

public class OrderDetails extends ProductDetails implements AmountCalculation{

	public int OrderId;
	public int customerId;
	public String customerName;
//	public int productId;
//	public String productName;
	public int productQuantity;
//	public int Amount;
//	public int total;
	

	public OrderDetails(int orderId2, int customerId2, String customerName2, int productId, String productName,
			int productQuantity2, int productPrice) {
		super(productId,productName,productPrice);
		OrderId = orderId2;
		this.customerId = customerId2;
		this.customerName=customerName2;
		this.productId = productId;
		this.productName = productName;
		this.productQuantity = productQuantity2;
		
	}

	@Override
	public int amountCalculation(int quantity, int productPrice) {
		
		return quantity*productPrice;
	}
	public int total(int amount)
	{
		amount+=amount;
		return amount;
	}
	public void ConfirmYourOrder()
	{
		System.out.println("OrderId:"+OrderId);
		System.out.println("customerId:"+this.customerId);
		System.out.println("customerName:"+this.customerName);
		System.out.println("Id:"+this.productId);
		System.out.println("Name:"+this.productName);
		System.out.println("Quantity:"+this.productQuantity);
		System.out.println("Price:"+productPrice);
		System.out.println("Amount:"+amountCalculation(this.productQuantity, productPrice));
	}

	public int getOrderId() {
		return OrderId;
	}

	public void setOrderId(int orderId) {
		OrderId = orderId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(int productQuantity) {
		this.productQuantity = productQuantity;
	}


}
