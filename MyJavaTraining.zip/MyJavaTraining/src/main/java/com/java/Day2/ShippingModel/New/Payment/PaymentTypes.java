package com.java.Day2.ShippingModel.New.Payment;

interface PaymentTypes {
	public String PaymentFunction();
}
