package com.java.Day2.ShippingModel.New.Products;

public class ProductDetails {

	public ProductDetails(int productId2, String productName2,  int productPrice2) {
		this.productId= productId2;
		this.productName=productName2;
		this.productPrice=productPrice2;
	}
	public int productId;
	public String productName;
	public int productPrice;
	
	public void ViewProduct()
	{
		System.out.println("Product Id:"+this.productId + "  Product Name:"+this.productName+"  Product Price:"+this.productPrice);
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

}
