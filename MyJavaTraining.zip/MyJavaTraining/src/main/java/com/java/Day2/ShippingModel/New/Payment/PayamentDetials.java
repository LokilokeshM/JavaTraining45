package com.java.Day2.ShippingModel.New.Payment;

import com.java.Day2.ShippingModel.New.Order.OrderDetails;

public class PayamentDetials extends OrderDetails implements PaymentTypes{

	public int paymentId;
	public String paymentMode;
	public String accountNumber;
	public String accountHolderName;
	
	
	
	public PayamentDetials(int orderId2, int customerId2, String customerName2, int productId, String productName,
			int productQuantity2, int productPrice, int paymentId, String paymentMode, String accountNumber,
			String accountHolderName) {
		super(orderId2, customerId2, customerName2, productId, productName, productQuantity2, productPrice);
		this.paymentId = paymentId;
		this.paymentMode = paymentMode;
		this.accountNumber = accountNumber;
		this.accountHolderName = accountHolderName;
	}

	public void printCustomerOrderDetails()
	{
		System.out.println("OrderId:"+OrderId);
		System.out.println("customerId:"+this.customerId);
		System.out.println("customerName:"+this.customerName);
		System.out.println("Id:"+this.productId);
		System.out.println("Name:"+this.productName);
		System.out.println("Quantity:"+this.productQuantity);
		System.out.println("Price:"+productPrice);
		System.out.println("Amount:"+amountCalculation(this.productQuantity, productPrice));
		System.out.println("Account Name:" +this.accountHolderName);
		System.out.println("Account Number:" +this.accountNumber);
		System.out.println("\n\n\n\n\n\n Your Order Willl Deliver Soon");
	}

	@Override
	public String PaymentFunction() {
		
		return null;
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	
	
	
}
//int paymentId,String paymentMode,String accountNumber,String accountHolderName
//this.paymentId=paymentId;
//this.paymentMode=paymentMode;
//this.accountNumber=accountNumber;
//this.accountHolderName=accountHolderName;