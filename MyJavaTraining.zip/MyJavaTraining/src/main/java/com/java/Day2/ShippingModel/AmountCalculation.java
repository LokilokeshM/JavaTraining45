package com.java.Day2.ShippingModel;

interface AmountCalculation {
	
	public static int cal() {
		return 0;
	}
}
