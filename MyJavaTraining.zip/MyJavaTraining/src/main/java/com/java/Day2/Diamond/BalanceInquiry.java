package com.java.Day2.Diamond;

public interface BalanceInquiry {	
	void checkBalance(double Amt);
}
