package com.java.Day2;

public interface Demo3 {

}
