package com.java.Day2;

import java.util.Scanner;

abstract class Product {
	int id;
	String name;
	int quantity;

	Product() {
		System.out.println("You Product Constructor is Created....");
	}

	void SetProductDetails(int id, String name, int quantity) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
	}

	void ShowProductDetails() {
		System.out.println("Product Id " + id);
		System.out.println("Product Name " + name);
		System.out.println("Product Quantity " + quantity);

	}
}

class Mobile extends Product {
	int sd;
	String os;
	int ram;

	Mobile() {
		System.out.println("You Mobile Constructor is Created....");
	}

	void SetProductDetails(int id, String name, int quantity, int sd, String os, int ram) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.os = os;
		this.sd = sd;
		this.ram = ram;
	}

	void ShowProductDetails() {
		System.out.println("Product Id " + id);
		System.out.println("Product Name " + name);
		System.out.println("Product Quantity " + quantity);
		System.out.println("Product ram " + ram);
		System.out.println("Product sd " + sd);
		System.out.println("Product os " + os);

	}
}

public class ShopingModel {

	public static void main(String[] args) {
		Mobile obj = new Mobile();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Product Name:");
		String name = sc.nextLine();
		System.out.println("Enter the Product Quantity:");
		int quantity = sc.nextInt();
		System.out.println("Enter the Ram Size");
		int ram = sc.nextInt();
		int sd = 256;
		String os = "Android";
		obj.SetProductDetails(1, name, quantity, sd, os, ram);
		obj.ShowProductDetails();


	}

}
