package com.java.Day2.ShippingModel.New.Order;

interface AmountCalculation {
	public int amountCalculation(int quantity,int rate);
}
