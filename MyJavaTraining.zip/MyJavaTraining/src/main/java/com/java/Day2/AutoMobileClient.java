package com.java.Day2;

import java.io.Serializable;

public class AutoMobileClient implements Serializable {
	public int aId = 0;
	public String aName;

	public AutoMobileClient(int aId, String aName) {
		super();
		this.aId = aId;
		this.aName = aName;
	}
	public void AppliedBreak(Boolean a)
	{
		if(a==true)
		{
			System.out.println("You Applied Break");
		}
		else
		{
			System.out.println("Not Applied Break");
		}
	}

	public int getaId() {
		return aId;
	}

	public void setaId(int aId) {
		this.aId = aId;
	}

	public String getaName() {
		return aName;
	}

	public void setaName(String aName) {
		this.aName = aName;
	}
	

}
