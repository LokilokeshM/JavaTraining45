package com.java.Day2.ShippingModel;

public abstract class Product {
	int id;
	String name;
	int quantity;

	Product() {
		System.out.println("You Product Constructor is Created....");
	}

	public void SetProductDetails(int id, String name, int quantity) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	void ShowProductDetails() {
		System.out.println("Product Id " + id);
		System.out.println("Product Name " + name);
		System.out.println("Product Quantity " + quantity);

	}
	
}
