package com.java.Day2;

public class Car extends AutoMobileClient{
	
	public String color;
	public Car(int aId, String aName,String color) {
		super(aId, aName);
		this.color=color;
		// TODO Auto-generated constructor stub
	}
				
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	
	public void moveYourVehicle(Boolean a)
	{
		if(a==true)
		{
			System.out.println("Your vehicle is moving.......");
		}
		else
		{
			System.out.println("Your Vehicle is Stoped.......");
		}
	}
}
