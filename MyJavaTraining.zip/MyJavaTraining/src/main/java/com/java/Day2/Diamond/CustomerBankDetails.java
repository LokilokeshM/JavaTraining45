package com.java.Day2.Diamond;
public class CustomerBankDetails {
String CustName,Email,BankName;
Long AccountNo,PhoneNo;
public CustomerBankDetails(String CustName,String Email,String BankName,Long AccountNo,Long PhoneNo) {
	this.CustName=CustName;
	this.BankName=BankName;
	this.Email=Email;
	this.AccountNo=AccountNo;
	this.PhoneNo=PhoneNo;
    }
}
