package com.java.Day2;

import java.io.*;
import java.util.*;

public class AutoMobiles {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Car cobj = new Car(0, null, null);
		cobj.setaName("Maruti");
		cobj.setaId(1);
		cobj.setColor("red");
		System.out.println("You want to move your car");
		String getvalue = "";
		System.out.println("Types Yes to move car......" + "No to apply Break.....");
		getvalue = sc.nextLine();
		String con = getvalue.toLowerCase();
		if(con.equals("yes"))
		{
			System.out.println(cobj.getaId());
			System.out.println(cobj.getaName());
			System.out.println(cobj.getColor());
			
			cobj.moveYourVehicle(true);
		
		}
		else
		{
			cobj.moveYourVehicle(false);
			cobj.AppliedBreak(true);
		}
		
	}

}
