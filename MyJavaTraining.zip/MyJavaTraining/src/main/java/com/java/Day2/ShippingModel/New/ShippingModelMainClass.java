package com.java.Day2.ShippingModel.New;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.java.Day2.ShippingModel.New.Order.OrderDetails;
import com.java.Day2.ShippingModel.New.Payment.PayamentDetials;
import com.java.Day2.ShippingModel.New.Products.ProductDetails;

public class ShippingModelMainClass {
	
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args)
	{
		String accountNumber = null;
		String accountName;
		List<ProductDetails> objProduct =new ArrayList();
		 objProduct.add(new ProductDetails(1, "OnePlus" , 100000));
		// objProduct.add(new ProductDetails(2, "Note Pro" , 100000));
		 objProduct.add(new ProductDetails(3, "Carrot" , 100000));
//		 objProduct.add(new ProductDetails(4, "Mangoes" , 100000));
//		 objProduct.add(new ProductDetails(5, "Apple" , 100000));
//		 objProduct.add(new ProductDetails(6, "Laptop" , 100000));
		 objProduct.add(new ProductDetails(7, "Bicycle" , 100000));
		 objProduct.add(new ProductDetails(8, "Hp" , 100000));
		 System.out.println("Enter Your Name to Start Your Purchace");
		 String name =sc.next();
		 if(name != null)
		 {
			 for(ProductDetails obj : objProduct)  obj.ViewProduct();	
			 System.out.println("Choose any Product");
			 String product = sc.next();
			 String conProduct =product.toLowerCase();
			 switch(conProduct)
			 {
			 case "onepls":
				 System.out.println("Enter the quantity for your oder");
				 int quantity =sc.nextInt();
//				 public OrderDetails(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice)
				 OrderDetails obj =new OrderDetails(genertateId(), genertateId() , name , 1 , "Oneplues", quantity, 100000);
				 obj.ConfirmYourOrder();
				 System.out.println("Press yes / No to Confirm your order");
				 String cnfrm =sc.next();
				 if(cnfrm.equalsIgnoreCase("yes"))
				 {
					 if(new ShippingModelMainClass().Pament().equalsIgnoreCase("online"))
					 {
						 //public PayamentDetials(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice, int paymentId, String paymentMode, String accountNumber,
//							String accountHolderName)
						 accountNumber = sc.next();
						 accountName =sc.next();
								 
						 PayamentDetials obj2 = new PayamentDetials(genertateId(), genertateId(), 
								 name, 1 , "One Plus", quantity, 100000, genertateId(),
								 new ShippingModelMainClass().Pament() , accountNumber, accountName);
						 
					 }
					 else
					 {
						 obj.ConfirmYourOrder();
						 System.out.println("Your Order Will be Deleivered Soon");
					 }
				 	}
				 else System.out.println("Thankyou visit again......");
				 break;
			 case "carrot":
				 System.out.println("Enter the quantity for your oder");
				  quantity =sc.nextInt();
//				 public OrderDetails(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice)
				  obj =new OrderDetails(genertateId(), genertateId() , name , 1 , "Oneplues", quantity, 100000);
				 obj.ConfirmYourOrder();
				 System.out.println("Press yes / No to Confirm your order");
				  cnfrm =sc.next();
				 if(cnfrm.equalsIgnoreCase("yes"))
				 {
					 if(new ShippingModelMainClass().Pament().equalsIgnoreCase("online"))
					 {
						 //public PayamentDetials(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice, int paymentId, String paymentMode, String accountNumber,
//							String accountHolderName)
						 accountNumber = sc.next();
						 accountName =sc.next();
								 
						 PayamentDetials obj2 = new PayamentDetials(genertateId(), genertateId(), 
								 name, 1 , "One Plus", quantity, 100000, genertateId(),
								 new ShippingModelMainClass().Pament() , accountNumber, accountName);
						 
					 }
					 else
					 {
						 obj.ConfirmYourOrder();
						 System.out.println("Your Order Will be Deleivered Soon");
					 }
				 	}
				 else System.out.println("Thankyou visit again......");
				 break;
			 case "hp":
				 System.out.println("Enter the quantity for your oder");
				  quantity =sc.nextInt();
//				 public OrderDetails(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice)
				  obj =new OrderDetails(genertateId(), genertateId() , name , 1 , "hp", quantity, 100000);
				 obj.ConfirmYourOrder();
				 System.out.println("Press yes / No to Confirm your order");
				  cnfrm =sc.next();
				 if(cnfrm.equalsIgnoreCase("yes"))
				 {
					 if(new ShippingModelMainClass().Pament().equalsIgnoreCase("online"))
					 {
						 //public PayamentDetials(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice, int paymentId, String paymentMode, String accountNumber,
//							String accountHolderName)
						 accountNumber = sc.next();
						 accountName =sc.next();
								 
						 PayamentDetials obj2 = new PayamentDetials(genertateId(), genertateId(), 
								 name, 1 , "One Plus", quantity, 100000, genertateId(),
								 new ShippingModelMainClass().Pament() , accountNumber, accountName);
						 
					 }
					 else
					 {
						 obj.ConfirmYourOrder();
						 System.out.println("Your Order Will be Deleivered Soon");
					 }
				 	}
				 else System.out.println("Thankyou visit again......");
				 break;
			 case "bicycle":
				 System.out.println("Enter the quantity for your oder");
				  quantity =sc.nextInt();
//				 public OrderDetails(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice)
				  obj =new OrderDetails(genertateId(), genertateId() , name , 1 , "bicycle", quantity, 100000);
				 obj.ConfirmYourOrder();
				 System.out.println("Press yes / No to Confirm your order");
				  cnfrm =sc.next();
				 if(cnfrm.equalsIgnoreCase("yes"))
				 {
					 if(new ShippingModelMainClass().Pament().equalsIgnoreCase("online"))
					 {
						 //public PayamentDetials(int orderId2, int customerId2, String customerName2, int productId, String productName,
//							int productQuantity2, int productPrice, int paymentId, String paymentMode, String accountNumber,
//							String accountHolderName)
						 accountNumber = sc.next();
						 accountName =sc.next();
								 
						 PayamentDetials obj2 = new PayamentDetials(genertateId(), genertateId(), 
								 name, 1 , "One Plus", quantity, 100000, genertateId(),
								 new ShippingModelMainClass().Pament() , accountNumber, accountName);
						 
					 }
					 else
					 {
						 obj.ConfirmYourOrder();
						 System.out.println("Your Order Will be Deleivered Soon");
					 }
				 	}
				 else System.out.println("Thankyou visit again......");
				 break;
			default:
				System.out.println("Enter the Valid Details...");
				break;
			 }
		 }	  
		 
	}
	
	public static int genertateId()
	 {
		Random rand = new Random();
		return rand.nextInt(10000000);
		 
	 }
	 public static String Pament()
	 {
		
			System.out.println("Enter Your Payment Mode:\n 1. Cash 2. Online"); 
			String pay =sc.next();
			return pay;
		 }
		
		 
	 }

