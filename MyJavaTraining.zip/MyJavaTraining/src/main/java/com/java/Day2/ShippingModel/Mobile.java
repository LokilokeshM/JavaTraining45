package com.java.Day2.ShippingModel;

class Mobile extends Product {
	int sd;
	String os;
	int ram;

	Mobile() {
		System.out.println("You Mobile Constructor is Created....");
	}

	public void SetProductDetails(int id, String name, int quantity, int sd, String os, int ram) {
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.os = os;
		this.sd = sd;
		this.ram = ram;
	}
	

	public int getSd() {
		return sd;
	}

	public void setSd(int sd) {
		this.sd = sd;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public int getRam() {
		return ram;
	}

	public void setRam(int ram) {
		this.ram = ram;
	}

	void ShowProductDetails() {
		System.out.println("Product Id " + id);
		System.out.println("Product Name " + name);
		System.out.println("Product Quantity " + quantity);
		System.out.println("Product ram " + ram);
		System.out.println("Product sd " + sd);
		System.out.println("Product os " + os);

}

	
}
