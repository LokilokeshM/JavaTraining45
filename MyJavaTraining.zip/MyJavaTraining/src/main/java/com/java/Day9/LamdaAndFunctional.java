package com.java.Day9;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.function.Function;
import java.util.stream.Collectors;

public class LamdaAndFunctional {

	public static void main(String[] args) {
		List<String> cities = Arrays.asList("London", "HongKong", "Paris", "NewYork");
		System.out.println("Original list : " + cities);
		System.out.println("list transformed :" + transform(cities));
		System.out.println("list transformed Before Java 8 Features : " + listsofString(cities));
		List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9);
		List<Integer> squares = numbers
				.stream()
				.map(i -> i * i)
				.collect(Collectors.toList());
		System.out.println("original list of numbers : " + numbers);
		
		System.out.println("transformed list of integers using Map in Java 8 : " + squares);
		System.out.println("processed list, only even numbers: " + new LamdaAndFunctional().UsingFilter());
		
		System.out.println("Priority Que With Lamda and Functional View.....");
		new LamdaAndFunctional().Priorityque();
		
		System.out.println("Function ");
		
		Function<Integer, Integer> dim = new Function<Integer, Integer>()
	      {
	         @Override
	         public Integer apply(Integer month)
	         {
	            return new Integer[] { 31, 28, 31, 30, 31, 30,
	                                   31, 31, 30, 31, 30, 31 }[month];
	         }
	      };
	      System.out.printf("April: %d%n", dim.apply(3));
	      System.out.printf("August: %d%n", dim.apply(7));
		
	}

	public static List<String> listsofString(List<String> listOfString) {
		List<String> coll = new ArrayList<>();
		for (String str : listOfString) {
			coll.add(str.toUpperCase());
		}
		return coll;
	}

	public static List<String> transform(List<String> listOfString) {
		return listOfString.stream() 
				.map(String::toUpperCase) 
				.collect(Collectors.toList());
	}

	public static List<Integer> UsingFilter() {
		List<String> numbers1 = Arrays.asList("1", "2", "3", "4", "5", "6");
		System.out.println("original list: " + numbers1);

		List<Integer> even = numbers1.stream().map(s -> Integer.valueOf(s)).filter(number1 -> number1 % 2 == 0)
				.collect(Collectors.toList());
		return even;
	}
	
	public static void Priorityque()
	{
		
        PriorityQueue<Integer> pQueue 
            = new PriorityQueue<Integer>( 
                Collections.reverseOrder()); 
        pQueue.add(30); 
        pQueue.add(20); 
        pQueue.add(400); 
  
        System.out.println("Head value using peek function:"
                           + pQueue.peek()); 
  
       
        System.out.println("The queue elements:"); 
        Iterator itr = pQueue.iterator(); 
        while (itr.hasNext()) 
            System.out.println(itr.next()); 
  
        pQueue.poll(); 
        System.out.println("After removing an element "
                           + "with Lamda poll  function:"); 
        Iterator<Integer> itr2 = pQueue.iterator(); 
        while (itr2.hasNext()) 
            System.out.println(itr2.next()); 
  
       
        pQueue.remove(30); 
        System.out.println("after removing 30 with"
                           + " remove function:"); 
        Iterator<Integer> itr3 = pQueue.iterator(); 
        while (itr3.hasNext()) 
            System.out.println(itr3.next()); 
  
        
        boolean b = pQueue.contains(20); 
        System.out.println("Priority queue contains 20 "
                           + "or not?: " + b); 
  
        Object[] arr = pQueue.toArray(); 
        System.out.println("Value in array: "); 
        for (int i = 0; i < arr.length; i++) 
            System.out.println("Value: "
                               + arr[i].toString());
		 
	}
}
