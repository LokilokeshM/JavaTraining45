package com.java.Day1;

import java.awt.List;
import java.io.*;
import java.util.*;

public class JavaProjectDay1 {

	public void ReverseString(String a) {
		char[] val = a.toCharArray();
		for (int i = a.length() - 1; i >= 0; i--) {
			System.out.println(val[i]);
		}
	}

	public void Swap(int a, int b) {
		a = a + b;
		b = a - b;
		a = a - b;
		System.out.println("a=" + a + " b= " + b);
	}

	public void Checkvowels(String s) {
		char[] ch = s.toCharArray();
		for (int i = 0; i <= s.length(); i++) {
			if (ch.equals("a") || ch.equals("e") || ch.equals("i") || ch.equals("o") || ch.equals("u")) {
				System.out.println("Vowels in a string is" + ch[i]);
			}

		}

	}

	public void Primeornot(int num) {
		boolean flag = false;
		for (int i = 2; i <= num / 2; ++i) {
			
			if (num % i == 0) {
				flag = true;
				break;
			}
		}

		if (!flag)
			System.out.println(num + " is a prime number.");
		else
			System.out.println(num + " is not a prime number.");
	}

	public static int fib(int n) {
		if (n <= 1)
			return n;
		return fib(n - 1) + fib(n - 2);
	}

	public void oddoreven(int[] a) {
		System.out.println("Odd Numbers:");
		for (int i = 0; i < a.length; i++) {
			if (a[i] % 2 != 0) {
				System.out.println(a[i]);
			}
		}
		System.out.println("Even Numbers:");
		for (int i = 0; i < a.length; i++) {
			if (a[i] % 2 == 0) {
				System.out.println(a[i]);
			}
		}
	}
	public void removeWhiteSpace(String s)
	{
		String str;
		str = s.replaceAll("\\s", ""); 
	    System.out.println(str); 	
	}
	public void factorial(int num)
	{
		int fact = 0;
		 for(int i=1;i<=num;i++){    
		      fact=fact*i;    
		  }    
		  System.out.println("Factorial of "+num+" is: "+fact);
	}
	public void secondlargest(int[] arr)
	{
		int temp;
		 for (int i = 0; i < arr.length; i++) {     
	            for (int j = i+1; j < arr.length; j++) {     
	               if(arr[i] > arr[j]) {    
	                   temp = arr[i];    
	                   arr[i] = arr[j];    
	                   arr[j] = temp;    
	               }     
	            }
	            }
		 System.out.println("The Second Largest Num in array"+arr[1]);
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter You option to Perform your Function");
		System.out.println("1.Reverse A String..");
		System.out.println("2.Swap Two Numbers ");
		System.out.println("3.Vowels in a string ");
		System.out.println("4.Prime or Not");
		System.out.println("5.Fibonacci Series");
		System.out.println("6.odd or Even");
		System.out.println("7. Remove White Space");
		System.out.println("8.Factorial");
		System.out.println("9.Second Largest Number in a array");
		int ch=sc.nextInt();
		switch(ch)
		{
		case 1:
			System.out.println("Enter String");
			String name=sc.nextLine();
			break;
		case 2:
			System.out.println("");
			break;
		case 3:
			System.out.println("");
			break;
		case 4:
			System.out.println("");
			break;
		case 5:
			System.out.println("");
			break;
		case 6:
			System.out.println("");
			break;
		case 7:
			System.out.println("");
			break;
		case 8:
			System.out.println("");
			break;
		case 9:
			System.out.println("");
			break;
		 default:
			System.out.println("");
			break;
		}
	}

}
