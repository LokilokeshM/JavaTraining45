package com.java.Day3;

import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import com.java.Day3.UserClient.sortbasedonFirstName;

public class OrderCustomer {

	public static void main(String[] args) {
		Map sortMap = new TreeMap<>();
		sortMap.put(5,new User(5, "loki4", "M", "Lokilokeshm1", 21));
		sortMap.put(6,new User(6, "loki5", "M", "Lokilokeshm1", 21));
		sortMap.put(7,new User(7, "loki6", "M", "Lokilokeshm1", 21));
		sortMap.put(8,new User(8, "loki7", "M", "Lokilokeshm1", 21));
		sortMap.put(9,new User(9, "loki8", "M", "Lokilokeshm1", 21));
		sortMap.put(10,new User(10, "loki9", "M", "Lokilokeshm1", 21));
		sortMap.put(1,new User(1, "loki", "M", "Lokilokeshm1", 21));
		sortMap.put(2,new User(2, "loki1", "M", "Lokilokeshm1", 21));
		sortMap.put(3,new User(3, "loki2", "M", "Lokilokeshm1", 21));
		sortMap.put(4,new User(4, "loki3", "M", "Lokilokeshm1", 21));
		
		Set value= sortMap.entrySet();
		Iterator itr= value.iterator();
		while(itr.hasNext())
		{
			System.out.println("==>"+itr.next().toString());	
		}

	}

}
