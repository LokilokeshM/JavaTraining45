package com.java.Day3;

public class User extends UserId {

	public String FirstName;
	public String LastName;
	public String Email;
	public int age;

	
	public User(int id, String firstName, String lastName, String email, int age) {
		super(id);
		FirstName = firstName;
		LastName = lastName;
		Email = email;
		this.age = age;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public int getAge() {
		return age;
	}

	public void setAge(short age) {
		this.age = age;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((FirstName == null) ? 0 : FirstName.hashCode());
		result = prime * result + ((LastName == null) ? 0 : LastName.hashCode());
		result = prime * result + ((Email == null) ? 0 : Email.hashCode());
		result = prime * result + age;
		return result;
	}

	@Override
	public String toString() {
		return "Payament [FirstName=" + FirstName + ", LastName=" + LastName + ", Email=" + Email + ", age=" + age
				+ "]";
	}

}
