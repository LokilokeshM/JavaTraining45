package com.java.Day3;

import java.util.*;

public class UserClient {

	public static void main(String[] args) {
		
		List myList = new ArrayList();
		//Set myList = new TreeSet();
		myList.add(new User(1, "loki", "M", "Lokilokeshm1", 21));
		myList.add(new User(2, "loki1", "M", "Lokilokeshm1", 21));
		myList.add(new User(3, "loki2", "M", "Lokilokeshm1", 21));
		myList.add(new User(4, "loki3", "M", "Lokilokeshm1", 21));
		myList.add(new User(5, "loki4", "M", "Lokilokeshm1", 21));
		myList.add(new User(6, "loki5", "M", "Lokilokeshm1", 21));
		myList.add(new User(7, "loki6", "M", "Lokilokeshm1", 21));
		myList.add(new User(8, "loki7", "M", "Lokilokeshm1", 21));
		myList.add(new User(9, "loki8", "M", "Lokilokeshm1", 21));
		myList.add(new User(10, "loki9", "M", "Lokilokeshm1", 21));
//		Collections.sort(myList,new sortbasedonFirstName());
		Iterator itr= myList.iterator();
		while(itr.hasNext())
		{
			System.out.println("==>"+itr.next().toString());	
		}
		
	}
	
//	class sortbasedonAge implements Comparator<User>{
//		@Override
//		public int compare(User obj1, User obj2) {
//			// TODO Auto-generated method stub
//			return obj1.getAge().compareTo(obj2.getAge());
//		}
//	}
	
	class sortbasedonFirstName implements Comparator<User>{

		@Override
		public int compare(User obj1, User obj2) {
			// TODO Auto-generated method stub
			return obj1.getFirstName().compareTo(obj2.getFirstName());
		}
		
	}
}
