package com.java.Day3;

public abstract class UserId {

	public int id;
	
	public UserId(int id) {
		this.id=id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

}
