package com.java.Day3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.*;

public class ListofOddNumber {
	public static boolean isNumeric(String str) {
		for (char c : str.toCharArray()) {
			if (!Character.isDigit(c))
				return false;
		}
		return true;
	}

	public void LitsofOdd() {
		String value = null;
		List<Integer> lI = new ArrayList<>();
		List<Integer> lO = new ArrayList<>();
		List<String> lS= new ArrayList<>();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the how many value that contain in a list.. ");
		int n = sc.nextInt();
		try {
			for (int i = 0; i < n; i++) {
				
				value = sc.next();
				
				if (isNumeric(value) == true) {
					
					int val = Integer.parseInt(value);
					if (val%2 !=0) {
						lO.add(val);	
					} else {
					lI.add(val);					}
				} 
				else
				{
					
				}

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		Iterator itr= lO.iterator();
		System.out.println("The Odd number in List");
		while(itr.hasNext())
		{
			
			System.out.println(itr.next());	
		}
//		Iterator itr1= lO.iterator();
//		while(itr1.hasNext())
//		{
//			System.out.println("The Even number in List");
//			System.out.println(itr1.next());	
//		}
//==		Iterator itr2= lO.iterator();
//		while(itr2.hasNext())
//		{
//			System.out.println("The String in List");
//			System.out.println(itr2.next());	
//		}

	}

	public static void main(String[] args) {

		new ListofOddNumber().LitsofOdd();

	}

}
