package com.java.Day3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class convertLinktoArray {

	public static void main(String[] args) {
		 LinkedList<User> myList = new LinkedList<User>();
		 myList.add(new User(1, "loki", "M", "Lokilokeshm1", 21));
			myList.add(new User(2, "loki1", "M", "Lokilokeshm1", 21));
			myList.add(new User(3, "loki2", "M", "Lokilokeshm1", 21));
			myList.add(new User(4, "loki3", "M", "Lokilokeshm1", 21));
			myList.add(new User(5, "loki4", "M", "Lokilokeshm1", 21));
			myList.add(new User(6, "loki5", "M", "Lokilokeshm1", 21));
			myList.add(new User(7, "loki6", "M", "Lokilokeshm1", 21));
			myList.add(new User(8, "loki7", "M", "Lokilokeshm1", 21));
			myList.add(new User(9, "loki8", "M", "Lokilokeshm1", 21));
			myList.add(new User(10, "loki9", "M", "Lokilokeshm1", 21));

		 List<User> list = new ArrayList<>(myList);

		    for (User str : list){
		      System.out.println(str.toString());
		    }

	}

}
