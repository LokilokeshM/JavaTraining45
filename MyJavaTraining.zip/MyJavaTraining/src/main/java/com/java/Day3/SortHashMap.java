package com.java.Day3;

import java.util.HashMap;
import java.util.Map;

import java.util.*;
public class SortHashMap {
	
public static void main(String[] args)
{
	HashMap<Integer,String> map = new HashMap<Integer,String>();
	map.put(5, "A");
	map.put(11, "C");
	map.put(4, "Z");
	map.put(77, "Y");
	map.put(9, "P");
	map.put(66, "Q");
	map.put(0, "R");

	Map<Integer,String> sortMap = new TreeMap<Integer,String>(map);
	Set sortset = sortMap.entrySet();
	Iterator iterator = sortset.iterator();
	while(iterator.hasNext()) {
	     Map.Entry val = (Map.Entry)iterator.next();
	     System.out.print(val.getKey() + ": ");
	     System.out.println(val.getValue());
	}
}
}
