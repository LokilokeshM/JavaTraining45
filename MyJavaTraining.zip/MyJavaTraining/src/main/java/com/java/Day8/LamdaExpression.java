package com.java.Day8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.java.Day3.User;

public class LamdaExpression {
	
	public static void main(String[] args) {
		 System.out.println("Display My Array List Using Lamda Functions");
		 new LamdaExpression().MyArrayList();
		 System.out.println("Display My Tree Map Using Lamda Functions");
		 new LamdaExpression().TreeMapCollection();
		 System.out.println("Display My Set  Using Lamda Functions");
		 new LamdaExpression().SetwithLamda();
		 
		 predicate_or(); 
		 
		 //User Module For Filter......
		 System.out.println("Get the Filter in User Module");
		 List<User1> users =  
	             new ArrayList<User1>(); 
	         users.add(new User1("John", "admin")); 
	         users.add(new User1("Peter", "member")); 
	           
	     List admins = users.stream() 
	     .filter((user) -> user.getRole().equals("admin")) 
	     .collect(Collectors.toList()); 
	           
	     System.out.println(admins); 
	}
	
 public void MyArrayList()
 {
	 List<User> myList = new ArrayList<User>();
		myList.add(new User(1, "loki", "M", "Lokilokeshm1", 21));
		myList.add(new User(2, "loki1", "M", "Lokilokeshm1", 21));
		myList.add(new User(3, "loki2", "M", "Lokilokeshm1", 21));
		myList.add(new User(4, "loki3", "M", "Lokilokeshm1", 21));
		myList.add(new User(5, "loki4", "M", "Lokilokeshm1", 21));
		myList.add(new User(6, "loki5", "M", "Lokilokeshm1", 21));
		
		myList.sort((p1, p2) -> p1.FirstName.compareTo(p2.FirstName));
		
		System.out.println(myList);
		
 }
 
 public void TreeMapCollection()
 {
	 TreeMap<Integer, User> m =  
             new TreeMap<Integer, User>((o1, o2) -> (o1 > o2) ?  
                                         -1 : (o1 < o2) ? 1 : 0); 
  m.put(1, new User(1, "loki", "M", "dsfasdf", 21)); 
  m.put(4, new User(2, "prem", "sdff", "sadfsdfsd", 20)); 
  m.put(5, new User(3, "magi", "sfdsaf", "fdffddf", 20)); 
  m.put(2, new User(4, "bertin", "fdf", "fdfdf", 20)); 
  m.put(3, new User(5, "kishore", "sdfs", "fdfdf", 20)); 
  System.out.println("After sorting Using Lamdaa Expression : " + m); 
 }
 
 public void SetwithLamda()
 {
	 Set<User> my_arr = new TreeSet<User>((p1, p2) -> p1.FirstName.compareTo(p2.FirstName));
	 my_arr.add(new User(1, "loki", "M", "Lokilokeshm1", 21));
	 my_arr.add(new User(2, "loki1", "M", "Lokilokeshm1", 21));
	 my_arr.add(new User(3, "loki2", "M", "Lokilokeshm1", 21));
     System.out.println("Sorted in Tree Set are : " + my_arr);
   
 }
 
 public static Predicate<String> hasLengthOf10 = new Predicate<String>() { 
     @Override
     public boolean test(String t) 
     { 
         return t.length() > 10; 
     } 
 }; 

 public static void predicate_or() 
 { 

     Predicate<String> containsLetterA = p -> p.contains("A"); 
     String containsA = "And"; 
     boolean outcome = hasLengthOf10.or(containsLetterA).test(containsA); 
     System.out.println(outcome); 
 } 
 
}
 class User1 
 { 
     String name, role; 
     User1(String a, String b) { 
         name = a; 
         role = b; 
     } 
     String getRole() { return role; } 
     String getName() { return name; }  
     public String toString() { 
     return "User Name : " + name + ", Role :" + role; 
     } 
}
