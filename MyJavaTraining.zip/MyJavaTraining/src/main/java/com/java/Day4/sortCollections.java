package com.java.Day4;

import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import com.java.Day5.EmployeeDetails;

public class sortCollections {
	public static void main(String[] args)
	{
		Map obj = new TreeMap();
		
		EmployeeDetails E1 = new EmployeeDetails(1, "loki", "Developer", 2);
		EmployeeDetails E2 = new EmployeeDetails(1, "loki", "Developer", 2);
		EmployeeDetails E3 = new EmployeeDetails(1, "loki", "Developer", 2);
		EmployeeDetails E4 = new EmployeeDetails(1, "loki", "Developer", 2);
		EmployeeDetails E5 = new EmployeeDetails(1, "loki", "Developer", 2);
		EmployeeDetails E6 = new EmployeeDetails(1, "loki", "Developer", 2);
		EmployeeDetails E7 = new EmployeeDetails(1, "loki", "Developer", 2);
		obj.put(GetEmployeeId(),E1);
		obj.put(GetEmployeeId(),E2);
		obj.put(GetEmployeeId(),E3);
		obj.put(GetEmployeeId(),E4);
		obj.put(GetEmployeeId(),E5);
		obj.put(GetEmployeeId(),E6);
		obj.put(GetEmployeeId(),E7);
		System.out.println(obj.toString());
		
	}
	public static int GetEmployeeId()
	{
		Random rand = new Random();
		return rand.nextInt(1000);
		
	}
}
