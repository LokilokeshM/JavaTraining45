package com.java.Day4;

import com.java.Day3.User;

import java.util.*;

public class GenericsCustomer {
	
	public static void main(String[] args)
	{
		YourCustomerObject<Integer,User> myList =new YourCustomerObject<>(1,new User(1, "loki", "M", "Lokilokeshm1", 21));
		YourCustomerObject<Integer,User> myList1 =new YourCustomerObject<>(1,new User(1, "loki", "M", "Lokilokeshm1", 21));
		myList.getUserObj();
		myList.getUserObj();
		//		Collections.sort(myList,Collections.reverseOrder());
		
		List<User> user = new ArrayList();
		
		user.add(new User(1, "loki", "M", "Lokilokeshm@", 21));
		user.add(new User(2, "magi", "M", "magi@", 21));
		user.add(new User(3, "prem", "M", "prem@", 21));
		user.add(new User(4, "bertin", "M", "Bertin@", 21));
		
		Collections.sort(user,new SortCustomer());
		
		System.out.println(user);	
	}
	
}
class YourCustomerObject<T,U>
{
	T obj;
	List obj1 = new ArrayList();
 	YourCustomerObject(T obj,U obj1)
	{
		this.obj =obj;
		this.obj1 = (List) obj1;
		if (obj instanceof User) {
			System.out.println("Instance of User is Created....");
		}	
	}
 	void getUserObj()
 	{
 		System.out.println(obj+ " " + obj1);
 	}
 	
}

class SortCustomer implements Comparator<User>
{

	@Override
	public int compare(User obj1, User obj2) {
		
		return obj1.getFirstName().compareTo(obj2.getFirstName());
	}
	
}
