package com.java.Day4;

import java.util.ArrayList;
import java.util.List;

import com.java.Day3.User;

class Bound<T extends A>
{
//	protected T obj=(T) new User(1, "loki", "M", "Lokilokeshm1", 21);
	private T objRef; 
    
    public Bound(T obj){ 
        this.objRef = obj; 
    } 
       
    public void doRunTest(){ 
        this.objRef.displayClass(); 
    } 
} 
   
class A 
{ 
    public void displayClass() 
    { 
        System.out.println("Inside super class A"); 
    } 
} 
   
class B extends A 
{ 
    public void displayClass() 
    { 
        System.out.println("Inside sub class B"); 
    } 
} 
   
class C extends A 
{ 
    public void displayClass() 
    { 
        System.out.println("Inside sub class C"); 
    } 
} 
public class MultipleBoundGenerics {
	public static void main(String[] args) {
		
        Bound<C> bec = new Bound<C>(new C()); 
        bec.doRunTest(); 
  
        Bound<B> beb = new Bound<B>(new B()); 
        beb.doRunTest(); 
  
        
        Bound<A> bea = new Bound<A>(new A()); 
        bea.doRunTest(); 
//          
//        Bound<String> bes = new Bound<String>(new String()); 
//        bea.doRunTest(); 
	}
}
