package com.java.Day6And7;



import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.sound.sampled.AudioFormat.Encoding;

import com.java.Day3.User;

class MultithreadingDemo implements Runnable 
{ 
    public void run() 
    { 
        try
        { 
            // Displaying the thread that is running 
            System.out.println ("Thread " + 
                                Thread.currentThread().getId() + 
                                " is running"); 
  
        } 
        catch (Exception e) 
        { 
            // Throwing an exception 
            System.out.println ("Exception is caught"); 
        } 
    } 
} 
 

class MultiThreadcsv
{
	public static void main(String[] args) 
	{
		try {
			
			 int n = 8; // Number of threads 
		        for (int i=0; i<n; i++) 
		        { 
		            Thread object = new Thread(new MultithreadingDemo()); 
		            object.start(); 
		            List<List<String>> rows = Arrays.asList(
						    Arrays.asList("Jean", "author", "Java"),
						    Arrays.asList("David", "editor", "Python"),
						    Arrays.asList("Scott", "editor", "Node.js")
						);
						System.out.println("Writing Alll The data in csv File");
						FileWriter csvWriter = new FileWriter("new.csv");
						csvWriter.append((CharSequence) new User(1, "loki", "M", "Lokilokeshm1", 21));
						csvWriter.append((CharSequence) new User(1, "Magi", "sdf", "magi", 21));
						csvWriter.append((CharSequence) new User(1, "Prem", "sadf", "prem", 21));
						csvWriter.append((CharSequence) new User(1, "Bertin", "Msdffa", "bertin", 21));
				
						for (List<String> rowData : rows) {
						    csvWriter.append(String.join(",", rowData));
						    csvWriter.append("\n");
						}

						csvWriter.flush();
						csvWriter.close();
		        } 
			
				
				BufferedReader csvReader = new BufferedReader(new FileReader("new.csv"));
				String row;
				while ((row = csvReader.readLine()) != null) {
				    String[] data = row.split(",");
				    System.out.println(data);
				}
				csvReader.close();
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
			

	}
	
}
